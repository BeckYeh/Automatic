我的網誌網址：http://blog.beck.idv.tw/

homework1：

可以使用 R/r 註冊新帳戶、L/l 登入、Q/q 退出

homework2：

輸入數字進到下一個地區，或是輸入 B/b 返回上地區，或是輸入 Q/q 退出