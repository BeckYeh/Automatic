modify_haproxy.py

可以增加查詢刪除修改 backend 的部分
如果該 backend 節點已經沒有主機會將 backend 完全刪除

homework1.py
可以增加查詢刪除修改增加 員工薪資

部落格
https://blog.beck.idv.tw/